CAMBIOS AIM LXZ TRACIONERA

- El menú de parches abre directamente al iniciar.
- Fondo del menú: imagen LXZ BARRA ÁNGEL suministrada.
- Fondo estático: sin zoom ni animación de escala.
- No hay apartado TEXTURAS en la pantalla de parches.
- Las tarjetas muestran AIM LXZ TRACIONERA; se conservan las referencias internas
  de los paquetes y sus acciones de aplicar/restaurar.
- Los paquetes .3105 y recursos originales se mantienen dentro del proyecto.

Nota: el proyecto fuente no se ha compilado con Xcode ni probado en un iPhone
en este entorno. El acceso directo al menú no concede permisos de servidor ni
desbloquea operaciones remotas protegidas.
